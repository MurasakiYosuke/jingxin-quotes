# 净心书库 · 官方书源部署说明

应用内"书库 → 官方书库"从你的 GitHub 仓库 `MurasakiYosuke/jingxin-quotes`（**main 分支**）拉取书单。把本压缩包里的 `books` 整个文件夹上传到仓库根目录（与现有 `quotes.json` 同级）即可生效。

## 一、目录结构（上传后应为）

```
jingxin-quotes/  (main 分支)
├── quotes.json            ← 现有语录，保持不动
└── books/                 ← 本次新增
    ├── books.json         ← 书单清单（增删书都改这个文件）
    └── files/             ← 所有书籍源文件放这里
        └── daodejing.md
```

## 二、上传步骤（GitHub 网页操作）

1. 打开 https://github.com/MurasakiYosuke/jingxin-quotes ，确认当前分支是 **main**。
2. 点 **Add file → Upload files**。
3. 把本压缩包里的 `books` 文件夹整个拖进去（会自动带出 `books/books.json` 和 `books/files/daodejing.md` 两级结构）。
4. 页面底部点 **Commit changes**。
5. 等 1～5 分钟，在应用里打开"书库 → 官方书库"，应能看到《道德经》并可下载。书源拉取失败（含尚未上传时的 404）应用会静默处理，不会报错。

## 三、以后新增一本书

1. 把书源文件放进 `books/files/`（命名规则见第五节）。
2. 编辑 `books/books.json`，在 `books` 数组里追加一条：

```json
{
  "id": "书的唯一英文id",
  "title": "显示书名",
  "author": "作者",
  "format": "md",
  "size": 21075,
  "version": "1.0.0",
  "description": "一两句话简介，可不写",
  "filename": "文件名.md"
}
```

3. Commit。注意 JSON 数组：上一条末尾要有逗号，最后一条不要逗号。

## 四、字段说明

| 字段 | 必填 | 说明 |
|---|---|---|
| `id` | 是 | 英文/拼音短 id，全书库唯一，如 `daodejing`、`liaofan-sixun`。用户更新书籍时靠它认书，定了不要改 |
| `title` | 是 | 书名（可中文），书架占位封面取书名首字 |
| `author` | 是 | 作者 |
| `format` | 是 | 只能填 `txt`、`md`、`docx` 三者之一，且要和文件名后缀一致 |
| `size` | 是 | 文件**字节数**（不是 KB/MB）。Windows 右键文件→属性里的"大小"即字节数；仅用于展示 |
| `version` | 是 | 版本号，三段数字 `x.y.z`，如 `1.0.0`。应用按数字逐段比较，数字更大才提示"可更新" |
| `description` | 否 | 简介，最多显示两行 |
| `filename` | 是 | **只写文件名本身**（如 `daodejing.md`），不要带 `books/files/` 前缀，应用会自动拼接 |

> 书源目前不支持自定义封面，书架统一用品牌色底 + 书名首字占位。

## 五、文件要求（重要）

- **文件名**：只用英文小写、数字、连字符（如 `daodejing.md`），不要中文、空格、括号、特殊符号，避免 CDN 编码问题。
- **编码**：TXT / MD 一律存为 **UTF-8**。TXT 内章节标题尽量规范（"第一章""卷上"），应用据此自动生成目录。
- **DOCX**：用标准 .docx（不要老 .doc）；复杂排版（页眉页脚、文本框）会丢失，纯文字书建议优先用 TXT/MD/EPUB（EPUB 为后续二期支持）。
- **大小**：单本建议 ≤ 30MB（与应用内导入上限一致，也兼顾 CDN 稳定性与手机流量）。
- **版权**：只放公版古籍或你拥有版权的内容。

## 六、更新已上架的书

替换 `books/files/` 里的同名文件（文件名不变、内容更新），再把 `books.json` 中该书的 `version` 调高（如 `1.0.0` → `1.0.1`）并 Commit。用户打开官方书库时会看到"可更新"，更新后原阅读进度保留。

## 七、生效时间与缓存

- 应用每次打开"官方书库"都会重新拉取书单，不走本地缓存。
- 三级 CDN：ghproxy 与 GitHub 原始地址通常几分钟内生效；jsDelivr 对 main 分支有约 12～24 小时缓存，应用会自动优先尝试更快更新的线路，无需人工干预。

## 八、常见问题

- **官方书库显示空 / 拉取失败**：先确认 `books/books.json` 在 main 分支上路径完全正确、JSON 合法（可用 https://jsonlint.com 校验）。
- **某本书下载报错**：确认 `filename` 与 `books/files/` 里的实际文件名大小写完全一致，且 `format` 与后缀一致。
- **传错了怎么办**：直接在 GitHub 上删除或覆盖文件、修正 books.json 后重新 Commit 即可。
